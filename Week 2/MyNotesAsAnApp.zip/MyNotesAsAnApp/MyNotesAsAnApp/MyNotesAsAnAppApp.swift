//
//  MyNotesAsAnAppApp.swift
//  MyNotesAsAnApp
//
//  Created by Tom Mazzag on 08/11/2023.
//

import SwiftUI

@main
struct MyNotesAsAnAppApp: App {
    var body: some Scene {
        WindowGroup {
            ScrumsView(scrums: DailyScrum.tomsData)
        }
    }
}
