//
//  ContentView.swift
//  MyNotesAsAnApp
//
//  Created by Tom Mazzag on 08/11/2023.
//

import SwiftUI

struct MyView: View {
    let scrum: DailyScrum
    let taken = 20
    var body: some View {
        VStack() {
            ProgressView(value: Double(taken), total: Double(scrum.lengthInMinutes * 60))
            HStack {
                VStack(alignment: .leading) {
                    Text("Time taken")
                    Label(String(taken), systemImage: "hourglass.tophalf.fill")
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("Time remaining")
                    Label(String(scrum.lengthInMinutes * 60 - taken), systemImage: "hourglass.bottomhalf.fill")
                }
            }
            Circle()
                .strokeBorder(.blue, lineWidth:10)
            HStack {
                Text("Deafault Text")
                Spacer()
                Button(action: {}) {
                    Image(systemName: "forward.fill")
                }
            }
        }
        .padding()

    }
}

#Preview {
    MyView(scrum: DailyScrum.tomsData[0])
}
