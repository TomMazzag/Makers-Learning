//
//  DetailView.swift
//  MyNotesAsAnApp
//
//  Created by Tom Mazzag on 09/11/2023.
//

import SwiftUI

struct DetailView: View {
    
    let scrum: DailyScrum

    var body: some View {
        List {
            Section(header: Text("Meeting Info")) {
            }
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            DetailView(scrum: DailyScrum.tomsData[0])
        }
    }
}
